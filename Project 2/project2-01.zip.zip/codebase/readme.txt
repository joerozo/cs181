- Modify the "CODEROOT" variable in makefile.inc to point to the root of your code base if necessary.

- Copy your own implementation of RBF component to folder "rbf"

- Implement the Relation Manager (RM):

- By default you should not change those functions of the RM and RM_ScanIterator class defined in rm/rm.h. If you think some changes are really necessary, please contact us first.
